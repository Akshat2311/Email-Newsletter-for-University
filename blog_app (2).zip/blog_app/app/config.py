
class Config:
    SECRET_KEY = 'd581f24a06b32b7a253427b66d160e12'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///site.db'
    MAIL_SERVER = 'smtp.office365.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = 'qa_amishra@outlook.com'
    MAIL_PASSWORD = 'Akshat@2311'